// ╔════════════════════════════════════════════════════════════════╗
// ║  FALCON PHARMA IMPEX — VIZIT NAZORAT TIZIMI                     ║
// ║  Google Apps Script — TO'LIQ BIRLASHTIRILGAN KOD (1 ta fayl)    ║
// ║  Versiya 6.0                                                      ║
// ╚════════════════════════════════════════════════════════════════╝
//
// BU KODNI QAYERGA QO'YISH KERAK:
//   "VISIT MA'LUMOTLARI" Google Sheets faylini oching →
//   Extensions (Kengaytmalar) → Apps Script →
//   Ochilgan oynadagi "Code.gs" faylining ICHIDAGI HAMMA narsani o'chiring →
//   Shu faylning BUTUN mazmunini joylashtiring → Saqlang (Ctrl+S) →
//   Deploy qiling (pastdagi QOLLANMA.md da rasm bilan ko'rsatilgan)
// ════════════════════════════════════════════════════════════════

// ──────────────────────────────────────────────────────────────
// ① SIZNING HAQIQIY SHEETS ID LARI
// ──────────────────────────────────────────────────────────────
const DB_SHEET_ID    = '1cimvRWTPKdCSaXOf65p1kHpV8vKTTEf9D16gE_KatEs'; // ВРАЧИ+АПТЕКИ+МП baza
const VISIT_SHEET_ID = '1suagqXDxWA3OyTHxqenykNfyu1v-VDt-SSQc9sogYdk'; // VISIT MA'LUMOTLARI (shu faylga skript qo'yiladi)

const TABS = {
  DOCTORS:     'ВРАЧИ',
  PHARMACIES:  'АПТЕКИ ПО ФИЛИАЛАМ',
  EMPLOYEES:   'Мед Представитель',
};

const OUT = VISIT_SHEET_ID;
const OUT_TABS = {
  VISITS_MP:    'Vizitlar_MP',
  VISITS_TA:    'Vizitlar_TA',
  PLANS:        'Rejalar_MP',
  PROMO:        'Promo_Sorovlar',
  MGR_PAYMENTS: 'Menejer_Tolovlari',
  MGR_BALANCE:  'Menejer_Balans',
  NEW_DOCTORS:  'Yangi_Vrachlar',
  NEW_PHARM:    'Yangi_Aptekalar',
  FEEDBACK:     'Murojaatlar',
  KPI_LOG:      'KPI_Log',
  LOCATIONS:    'Lokatsiyalar',
  LOGIN:        'Hodimlar_Login',
};

// ──────────────────────────────────────────────────────────────
// ② ADMIN EMAIL — O'ZGARTIRING!
// ──────────────────────────────────────────────────────────────
const ADMIN_EMAIL = 'sizning.email@gmail.com'; // ★★★ BU YERGA O'Z GMAIL MANZILINGIZNI YOZING

// KPI normalari
const KPI_NORM = { doctorVisits: 12 };
const TP_NORM_PHARMACY = 25;
const MIN_VISIT_SEC = 300; // 5 daqiqa

// 25 preparat va narxlar
const PREPS = [
  'ФДП - Ментор 5гр №1','ФДП - Ментор 10гр №1','Фдп-Sinopharm 10г (флаконы)',
  'Ментофер 100мг/5мл №5','Л-ЦИНАТ 5мг №10','БЕРРИМУН Сироп 100мл №1',
  'ГРОВЭЛЛ Сироп 120мл №1','КАЛМИСОН Сироп 150мл №1','КАРВИЛИКС Сироп 120мл №1',
  'СОЛАРВИТ Капли 10мл №1','СОНВИЛ Капли 50мл №1','ФРУТАВИЛ Капли 50мл №1',
  'ДОЛАТИХИН Капсула №60','ЗЕРАПРОСТ Капсула №30','НИТИРОЛ Таблетка №30',
  'НЕФИТОР Таблетка №30','ПОГЕНИЛ Таблетка №30','ТИРОФОРТ Таблетка №30',
  'ОЯВИС Капсулы №60','МЕНАПОЛ Капсулы №60','ИММУНОФОР Капсулы №20',
  'BioAmicus REUTERI 10мл','BioAmicus COMPLETE 10мл','BioAmicus VITAMIN D3 10мл',
  'BioAmicus OMEGA-3 30мл',
];
const PRICES = [
  168038.06,235828.91,238663.53,250196.48,175125.36,145600,123200,145600,
  162400,112000,123200,134400,364000,160160,129920,135520,135520,147840,
  160160,246400,147840,168000,168000,145600,140000,
];

// ════════════════════════════════════════════════════════════════
// ROUTING
// ════════════════════════════════════════════════════════════════
function doGet(e) {
  const a = (e.parameter.action || 'ping').trim();
  let r;
  try {
    switch (a) {
      case 'getDoctors':    r = getDoctors();                                      break;
      case 'getPharmacies': r = getPharmacies();                                   break;
      case 'getEmployees':  r = getEmployeesPublic();                              break;
      case 'checkLoginGet': r = checkLogin({id:e.parameter.id, pass:e.parameter.pass}); break;
      case 'getPlans':      r = getPlans(e.parameter.empId, e.parameter.role);     break;
      case 'getKPI':        r = getKPI(e.parameter.empId, e.parameter.role, e.parameter.date); break;
      case 'getPromoQueue': r = getPromoQueue(e.parameter.empId, e.parameter.role);break;
      case 'getMgrBalance': r = getMgrBalance(e.parameter.mgrId);                  break;
      case 'getMgrPayments':r = getMgrPayments(e.parameter.mgrId, e.parameter.date); break;
      case 'getPriceMap':   r = getPriceMapFn();                                   break;
      case 'getLocations':  r = getLocations(e.parameter.empId, e.parameter.role, e.parameter.days); break;
      default: r = { status:'ok', v:'6.0', t:new Date().toISOString() };
    }
  } catch (err) { r = { error: err.message }; Logger.log('doGet ' + a + ': ' + err); }
  return out(r);
}

function doPost(e) {
  let d;
  try { d = JSON.parse(e.postData.contents); }
  catch (err) { return out({ error:'JSON: ' + err.message }); }
  let r;
  try {
    switch (d.action) {
      case 'checkLogin':      r = checkLogin(d);          break;
      case 'addVisitMP':      r = addVisitMP(d);          break;
      case 'addVisitTA':      r = addVisitTA(d);          break;
      case 'addPlan':         r = addPlan(d);             break;
      case 'updatePlan':      r = updatePlanStatus(d);    break;
      case 'requestPromo':    r = requestPromo(d);        break;
      case 'decidePromo':     r = decidePromo(d);         break;
      case 'mgrPayDoctor':    r = mgrPayDoctor(d);        break;
      case 'setMgrBalance':   r = setMgrBalance(d);       break;
      case 'addNewDoctor':    r = addNewDoctor(d);        break;
      case 'addNewPharmacy':  r = addNewPharmacy(d);      break;
      case 'saveBranchNo':    r = saveBranchNo(d);        break;
      case 'submitFeedback':  r = submitFeedback(d);      break;
      case 'endDay':          r = endDay(d);              break;
      default: r = { error:'Noma\'lum: ' + d.action };
    }
  } catch (err) { r = { error: err.message }; Logger.log('doPost ' + d.action + ': ' + err); }
  return out(r);
}
function out(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

// ════════════════════════════════════════════════════════════════
// VRACHLAR (ВРАЧИ tab)
// ════════════════════════════════════════════════════════════════
function getDoctors() {
  const ss = SpreadsheetApp.openById(DB_SHEET_ID);
  const sh = ss.getSheetByName(TABS.DOCTORS);
  if (!sh) return { error:'ВРАЧИ topilmadi' };
  const rows = sh.getDataRange().getValues();
  const out = [];
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    if (!r[1]) continue;
    out.push({
      id: 'V' + (i+1), region:String(r[0]||''), name:String(r[1]||''),
      object:String(r[2]||''), specialty:String(r[3]||''), district:String(r[4]||''),
      phone:String(r[5]||''), category:String(r[6]||''), status:String(r[7]||''),
    });
  }
  return out;
}

// ════════════════════════════════════════════════════════════════
// APTEKALAR (АПТЕКИ ПО ФИЛИАЛАМ tab)
// ════════════════════════════════════════════════════════════════
function getPharmacies() {
  const ss = SpreadsheetApp.openById(DB_SHEET_ID);
  const sh = ss.getSheetByName(TABS.PHARMACIES);
  if (!sh) return { error:'АПТЕКИ ПО ФИЛИАЛАМ topilmadi' };
  const rows = sh.getDataRange().getValues();
  const out = [];
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    if (!r[3]) continue;
    const raw = String(r[3]);
    const parts = raw.split('|');
    const inn = (parts[0]||'').trim();
    const legalName = (parts[1]||'').trim().replace(/^["“]+|["”]+$/g,'');
    out.push({
      id: 'P' + (i+1), rowNum: i+1, region:String(r[1]||''), district:String(r[2]||''),
      inn, legalName, raw, branch: String(r[4]||''),
    });
  }
  return out;
}

function saveBranchNo(d) {
  const ss = SpreadsheetApp.openById(DB_SHEET_ID);
  const sh = ss.getSheetByName(TABS.PHARMACIES);
  if (!sh) return { error:'sheet topilmadi' };
  sh.getRange(d.rowNum, 5).setValue(d.branchNo);
  return { status:'ok' };
}

// ════════════════════════════════════════════════════════════════
// HODIMLAR (LOGIN) — Mukammal, unikal, takrorlanmaydigan parollar
// ════════════════════════════════════════════════════════════════
function getEmployeesPublic() {
  const emps = loadEmployees();
  const pub = {};
  Object.keys(emps).forEach(id => { pub[id] = { name:emps[id].name, role:emps[id].role, region:emps[id].region }; });
  return pub;
}

function loadEmployees() {
  const ss2 = SpreadsheetApp.openById(OUT);
  let sh = ss2.getSheetByName(OUT_TABS.LOGIN);
  if (!sh) return createDefaultLogins(ss2);
  return readLoginSheet(sh);
}

function readLoginSheet(sh) {
  const rows = sh.getDataRange().getValues();
  const out = {};
  for (let i = 1; i < rows.length; i++) {
    const r = rows[i];
    if (!r[0]) continue;
    out[String(r[0]).trim()] = {
      name:String(r[1]||''), role:String(r[2]||'mp').toLowerCase(),
      pass:String(r[3]||''), region:String(r[4]||'Toshkent shahri'),
      mgrId:String(r[5]||''),
    };
  }
  return out;
}

// Birinchi marta ishga tushganda — barcha login/parollarni AVTOMATIK
// generatsiya qiladi, hech qaysi ikkitasi bir xil bo'lmaydi, va sizga
// email orqali to'liq ro'yxatni yuboradi.
function createDefaultLogins(ss) {
  const sh = ss.insertSheet(OUT_TABS.LOGIN);
  const hdr = ['ID','Ism','Rol','Parol','Region','MenejerID'];
  sh.appendRow(hdr); styleHdr(sh, hdr.length, '#0e2248');

  const out = {};
  const rows_ = [];
  const usedPasswords = new Set(); // Takrorlanmasligini kafolatlash uchun

  function uniquePass() {
    let p;
    do { p = genPass(); } while (usedPasswords.has(p));
    usedPasswords.add(p);
    return p;
  }

  // 1 ta ADMIN — hammani ko'ra oladi
  rows_.push(['ADMIN', 'Administrator', 'admin', uniquePass(), 'Toshkent shahri', '']);

  // Menejerlar va MP lar — sizning haqiqiy "Мед Представитель" tab'idan
  try {
    const dbss = SpreadsheetApp.openById(DB_SHEET_ID);
    const mpSh = dbss.getSheetByName(TABS.EMPLOYEES);
    const mpRows = mpSh.getDataRange().getValues();
    const mgrNames = [...new Set(mpRows.slice(1).map(r => r[1]).filter(Boolean))];
    const mgrIds = {};
    mgrNames.forEach((name, idx) => {
      const id = 'MGR' + String(idx+1).padStart(2,'0');
      mgrIds[name] = id;
      rows_.push([id, name, 'manager', uniquePass(), 'Toshkent', '']);
    });
    let mpCount = 0;
    for (let i = 1; i < mpRows.length; i++) {
      const mgrName = mpRows[i][1], mpName = mpRows[i][2];
      if (!mpName) continue;
      mpCount++;
      const id = 'MP' + String(mpCount).padStart(2,'0');
      rows_.push([id, mpName, 'mp', uniquePass(), String(mpRows[i][3]||'Toshkent shahri'), mgrIds[mgrName]||'']);
    }
  } catch (e) { Logger.log('MP import xato: ' + e); }

  // Torgovoy Agent — 2 ta (siz aniqlashtirgan: Ivan va Akmal)
  rows_.push(['TA01', 'Deryabin Ivan', 'ta', uniquePass(), 'Toshkent shahri', '']);
  rows_.push(['TA02', 'Anvarxodjayev Akmal', 'ta', uniquePass(), 'Toshkent shahri', '']);

  rows_.forEach(r => sh.appendRow(r));
  rows_.forEach(r => { out[r[0]] = { name:r[1], role:r[2], pass:r[3], region:r[4], mgrId:r[5] }; });

  try {
    let body = 'Falcon Pharma Impex CRM — barcha login/parollar (har biri UNIKAL):\n\n';
    rows_.forEach(r => {
      const roleLabel = {admin:'Administrator', manager:'Menejer', mp:'Med. Vakil', ta:'Torgovoy Agent'}[r[2]];
      body += r[0] + ' — ' + r[1] + ' (' + roleLabel + ')\n   Parol: ' + r[3] + '\n\n';
    });
    body += '\nBu ro\'yxat "Hodimlar_Login" sheetda saqlangan (VISIT MA\'LUMOTLARI faylida).';
    MailApp.sendEmail(ADMIN_EMAIL, 'Falcon Pharma Impex — Barcha Login/Parollar', body);
  } catch (e) {}

  return out;
}

function genPass() {
  const c = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';
  let p=''; for (let i=0;i<8;i++) p+=c[Math.floor(Math.random()*c.length)];
  return p;
}

function checkLogin(d) {
  const emps = loadEmployees();
  const emp = emps[String(d.id||'').trim().toUpperCase()];
  if (!emp || emp.pass !== d.pass) return { status:'error' };
  return { status:'ok', name:emp.name, role:emp.role, region:emp.region, mgrId:emp.mgrId };
}

function getPriceMapFn() { const m = {}; PREPS.forEach((p,i) => m[p]=PRICES[i]); return m; }

// ════════════════════════════════════════════════════════════════
// MP — VRACH VIZITI
// ════════════════════════════════════════════════════════════════
const HDR_MP = [
  // Vizit umumiy ma'lumotlar
  'Yozilgan vaqt','Sana','Med. Vakil ID','Med. Vakil F.I.Sh','Mintaqa','Menejer ID',
  // Vrach ma'lumotlari
  'Vrach F.I.Sh','Mutaxassisligi','Ish joyi (obyekt)','Tuman','Kategoriya','Telefon raqami',
  // Vizit maqsadi
  'Vizit maqsadi','Vizit maqsadi (qo\'shimcha)',
  // Tavsiya etilgan preparatlar (5 tagacha)
  'Preparat 1','Soni 1','Preparat 2','Soni 2','Preparat 3','Soni 3','Preparat 4','Soni 4','Preparat 5','Soni 5',
  // Natija
  'Probnik berildi','Natija','Natija (qo\'shimcha)',
  // Proma
  'Proma so\'raldi','Proma ID','Qo\'sh vizit (2x)',
  // Keyingi reja
  'Keyingi vizit sanasi','Izoh',
  // Vaqt va joylashuv
  'Vizit boshlandi','Vizit tugadi','Davomiylik (soniya)','Kenglik (lat)','Uzunlik (lng)','GPS aniqlik (metr)',
  // Qo'shimcha
  'Foto havolasi','Shubhali (FAKE sababi)','Havola ID',
];

function addVisitMP(d) {
  const sh = getOrCreate(OUT, OUT_TABS.VISITS_MP, HDR_MP, '#0e2248');
  const dur = Number(d.durationSec)||0, acc = Number(d.gpsAcc)||9999;
  const gs = d.gpsStart||{}, ge = d.gpsEnd||{};
  const reasons = [];
  if (dur < MIN_VISIT_SEC) reasons.push('Davomiylik '+dur+'s<'+MIN_VISIT_SEC+'s');
  if (acc > 500) reasons.push('GPS aniqlik '+acc+'m');
  if (gs.lat && ge.lat) { const dist=haversine(gs.lat,gs.lng,ge.lat,ge.lng); if (dist>300) reasons.push('Start/End '+Math.round(dist)+'m'); }
  const fake = reasons.length>0;

  const prods = (d.products||[]).slice(0,5);
  while (prods.length<5) prods.push({name:'',qty:0});

  let foto='';
  if (d.fotoBase64) { try { foto = saveFoto(d.fotoBase64, d.ref, 'MP_'+d.empId); } catch(e){ foto='XATO'; } }

  const row = [
    new Date().toISOString(), d.date, d.empId, d.empName, d.region||'', d.mgrId||'',
    d.doctorName, d.doctorSpec, d.doctorObject, d.doctorDistrict, d.doctorCategory, d.doctorPhone,
    d.goal, d.goalOther||'',
    prods[0].name,prods[0].qty,prods[1].name,prods[1].qty,prods[2].name,prods[2].qty,prods[3].name,prods[3].qty,prods[4].name,prods[4].qty,
    d.sampleRequested?'Ha':'Yo\'q', d.result, d.resultOther||'',
    d.promoRequested?'Ha':'Yo\'q', d.promoId||'', d.promoRequested?'Ha':'Yo\'q',
    d.nextVisitDate, d.comment,
    d.visitStartTime, d.visitEndTime, dur,
    ge.lat||gs.lat||'', ge.lng||gs.lng||'', acc,
    foto, fake?reasons.join('; '):'Yo\'q', d.ref,
  ];
  sh.appendRow(row);
  const lr = sh.getLastRow();
  const colors = {'ISHLAYDI':'#d4f5e8','QABUL QILMADI':'#fde0dc','OYLAMOQDA':'#fff3cd','INFO':'#e3eefc'};
  sh.getRange(lr,1,1,row.length).setBackground(colors[d.result]||'#fff');
  if (fake) { sh.getRange(lr,1,1,row.length).setBackground('#ffd6d6'); sh.getRange(lr,1).setNote('SHUBHALI:\n'+reasons.join('\n')); }
  if (dur < MIN_VISIT_SEC) { const c=HDR_MP.indexOf('Davomiylik (s)')+1; sh.getRange(lr,c).setBackground('#ff4d4d').setFontColor('#fff').setFontWeight('bold'); }

  if (ge.lat||gs.lat) logLocation(d.empId, d.empName, 'mp', 'doctor', d.doctorName, ge.lat||gs.lat, ge.lng||gs.lng, d.date);

  const nw = new Date(); nw.setDate(nw.getDate()+7);
  addPlan({ empId:d.empId, empName:d.empName, type:'doctor', targetName:d.doctorName,
    targetObject:d.doctorObject, date:Utilities.formatDate(nw,'Asia/Tashkent','yyyy-MM-dd'),
    goal:'Takroriy vizit (avto)', status:'Tasdiqlangan', createdAt:new Date().toISOString() });

  logKPI(d.empId, d.empName, d.date, 'mp_doctor', d.result, fake);
  return { status:'ok', ref:d.ref, fake, fakeReasons:reasons };
}

// ════════════════════════════════════════════════════════════════
// TA — DORIXONA VIZITI (Bron + Qoldiq)
// ════════════════════════════════════════════════════════════════
function buildHdrTA() {
  const base = ['Отметка времени','ДАТА','ТП ID','ТП Ф.И.О','Регион','Район',
    'Apteka (INN)','Apteka nomi','Filial','Yangi apteka',
    'Izoh','Vizit boshlandi','Vizit tugadi','Davomiylik (soniya)','Kenglik (lat)','Uzunlik (lng)','GPS aniqlik (metr)',
    'Foto URL','Shubhali','Umumiy summa','REF'];
  const prepCols = [];
  PREPS.forEach(p => { prepCols.push(p+' (bron)'); prepCols.push(p+' (qoldiq)'); prepCols.push(p+' (summa)'); });
  const idx = base.indexOf('Комментарий');
  return base.slice(0,idx).concat(prepCols, base.slice(idx));
}

function addVisitTA(d) {
  const HDR = buildHdrTA();
  const sh = getOrCreate(OUT, OUT_TABS.VISITS_TA, HDR, '#0f6e56');
  const dur = Number(d.durationSec)||0, acc = Number(d.gpsAcc)||9999;
  const gs=d.gpsStart||{}, ge=d.gpsEnd||{};
  const reasons=[];
  if (dur<MIN_VISIT_SEC) reasons.push('Davomiylik '+dur+'s');
  if (acc>500) reasons.push('GPS '+acc+'m');
  if (gs.lat&&ge.lat) { const dist=haversine(gs.lat,gs.lng,ge.lat,ge.lng); if(dist>300) reasons.push('Start/End '+Math.round(dist)+'m'); }
  const fake = reasons.length>0;

  const bronMap={}, stockMap={};
  (d.bron||[]).forEach(s=>bronMap[s.prep]=Number(s.qty)||0);
  (d.stock||[]).forEach(s=>stockMap[s.prep]=Number(s.qty)||0);

  let total=0; const cells=[];
  PREPS.forEach((p,i)=>{
    const bron=bronMap[p]||0, qty=stockMap[p]||0, sum=qty*PRICES[i];
    total+=sum; cells.push(bron, qty, sum);
  });

  let foto=''; if (d.fotoBase64) { try{foto=saveFoto(d.fotoBase64,d.ref,'TA_'+d.empId);}catch(e){foto='XATO';} }

  const row = [
    new Date().toISOString(), d.date, d.empId, d.empName, d.region, d.district,
    d.pharmInn, d.pharmName, d.branchNo, d.isNewPharmacy?'Ha':'Yo\'q',
  ].concat(cells, [
    d.comment, d.visitStartTime, d.visitEndTime, dur,
    ge.lat||gs.lat||'', ge.lng||gs.lng||'', acc,
    foto, fake?reasons.join('; '):'Yo\'q', total, d.ref,
  ]);
  sh.appendRow(row);
  const lr = sh.getLastRow();
  if (fake) { sh.getRange(lr,1,1,row.length).setBackground('#ffd6d6'); sh.getRange(lr,1).setNote('SHUBHALI:\n'+reasons.join('\n')); }
  if (dur<MIN_VISIT_SEC) { const c=HDR.indexOf('Davomiylik (s)')+1; sh.getRange(lr,c).setBackground('#ff4d4d').setFontColor('#fff').setFontWeight('bold'); }

  if (ge.lat||gs.lat) logLocation(d.empId, d.empName, 'ta', 'pharmacy', d.pharmName, ge.lat||gs.lat, ge.lng||gs.lng, d.date);

  logKPI(d.empId, d.empName, d.date, 'ta_pharmacy', 'Vizit', fake);
  return { status:'ok', ref:d.ref, fake, fakeReasons:reasons, total };
}

// ════════════════════════════════════════════════════════════════
// REJA — FAQAT MP UCHUN
// ════════════════════════════════════════════════════════════════
const HDR_PLAN = ['Hodim ID','Hodim F.I.Sh','Menejer ID','Tur','Ob\'ekt nomi','Ish joyi','Sana','Maqsad','Holati','Yaratilgan vaqti'];

function addPlan(d) {
  const sh = getOrCreate(OUT, OUT_TABS.PLANS, HDR_PLAN, '#0e2248');
  sh.appendRow([d.empId,d.empName,d.mgrId||'',d.type,d.targetName,d.targetObject||'',
    d.date,d.goal,d.status||'Kutilmoqda',d.createdAt||new Date().toISOString()]);
  return { status:'ok' };
}

function getPlans(empId, role) {
  const sh = SpreadsheetApp.openById(OUT).getSheetByName(OUT_TABS.PLANS);
  if (!sh) return [];
  const rows = sh.getDataRange().getValues();
  if (rows.length<2) return [];
  const hdr = rows[0]; const out=[];
  for (let i=1;i<rows.length;i++) {
    const r=rows[i]; if(!r[0]) continue;
    const item={}; hdr.forEach((h,j)=>item[h]=r[j]); item._row=i+1;
    if (role==='mp' && item.empId!==empId) continue;
    if (role==='manager' && item.mgrId!==empId) continue;
    out.push(item);
  }
  return out;
}

function updatePlanStatus(d) {
  const sh = SpreadsheetApp.openById(OUT).getSheetByName(OUT_TABS.PLANS);
  if (!sh) return { error:'topilmadi' };
  sh.getRange(d.row, HDR_PLAN.indexOf('status')+1).setValue(d.status);
  if (d.newDate) sh.getRange(d.row, HDR_PLAN.indexOf('date')+1).setValue(d.newDate);
  if (d.newGoal) sh.getRange(d.row, HDR_PLAN.indexOf('goal')+1).setValue(d.newGoal);
  return { status:'ok' };
}

// ════════════════════════════════════════════════════════════════
// PROMO SO'ROVI
// ════════════════════════════════════════════════════════════════
const HDR_PROMO = ['PromoID','empId','empName','mgrId','doctorName','doctorObject',
  'sana','izoh','status','createdAt'];

function requestPromo(d) {
  const sh = getOrCreate(OUT, OUT_TABS.PROMO, HDR_PROMO, '#b56f00');
  const id = 'PROMO-'+Date.now();
  sh.appendRow([id, d.empId, d.empName, d.mgrId||'', d.doctorName, d.doctorObject,
    d.date, d.izoh||'', 'Kutilmoqda', new Date().toISOString()]);
  sh.getRange(sh.getLastRow(),1,1,HDR_PROMO.length).setBackground('#fff3cd');
  try {
    MailApp.sendEmail(ADMIN_EMAIL, '[FF] Yangi promo so\'rovi: '+d.empName,
      'MP: '+d.empName+'\nVrach: '+d.doctorName+' ('+d.doctorObject+')\nSana: '+d.date+
      '\n\nMenejer saytdan tasdiqlab, vrachga pul berish jarayonini boshlaydi.');
  } catch(e) {}
  return { status:'ok', promoId:id };
}

function getPromoQueue(empId, role) {
  const sh = SpreadsheetApp.openById(OUT).getSheetByName(OUT_TABS.PROMO);
  if (!sh) return [];
  const rows = sh.getDataRange().getValues();
  if (rows.length<2) return [];
  const hdr=rows[0]; const out=[];
  for (let i=1;i<rows.length;i++) {
    const r=rows[i]; if(!r[0]) continue;
    const item={}; hdr.forEach((h,j)=>item[h]=r[j]); item._row=i+1;
    if (role==='manager' && item.mgrId!==empId) continue;
    if (role==='mp' && item.empId!==empId) continue;
    out.push(item);
  }
  return out;
}

function decidePromo(d) {
  const sh = SpreadsheetApp.openById(OUT).getSheetByName(OUT_TABS.PROMO);
  if (!sh) return { error:'topilmadi' };
  const statusCol = HDR_PROMO.indexOf('status')+1;
  sh.getRange(d.row, statusCol).setValue(d.approved?'Tasdiqlandi':'Rad etildi');
  sh.getRange(d.row,1,1,HDR_PROMO.length).setBackground(d.approved?'#d4f5e8':'#fde0dc');
  return { status:'ok' };
}

// ════════════════════════════════════════════════════════════════
// MENEJER PUL TIZIMI
// ════════════════════════════════════════════════════════════════
const HDR_MGR_BAL = ['Menejer ID','Menejer F.I.Sh','Ajratilgan summa (so\'m)','Sarflangan (so\'m)','Qolgan (so\'m)','Oxirgi yangilanish'];

function setMgrBalance(d) {
  const sh = getOrCreate(OUT, OUT_TABS.MGR_BALANCE, HDR_MGR_BAL, '#1a3c6e');
  const rows = sh.getDataRange().getValues();
  let foundRow = -1;
  for (let i=1;i<rows.length;i++) if (rows[i][0]===d.mgrId) { foundRow=i+1; break; }
  if (foundRow>0) {
    sh.getRange(foundRow,3).setValue(d.summa);
    sh.getRange(foundRow,5).setValue(Number(d.summa) - Number(rows[foundRow-1][3]||0));
    sh.getRange(foundRow,6).setValue(new Date().toISOString());
  } else {
    sh.appendRow([d.mgrId, d.mgrName, d.summa, 0, d.summa, new Date().toISOString()]);
  }
  return { status:'ok' };
}

function getMgrBalance(mgrId) {
  const sh = SpreadsheetApp.openById(OUT).getSheetByName(OUT_TABS.MGR_BALANCE);
  if (!sh) return { jami:0, sarflangan:0, qolgan:0 };
  const rows = sh.getDataRange().getValues();
  for (let i=1;i<rows.length;i++) {
    if (rows[i][0]===mgrId) return { jami:rows[i][2], sarflangan:rows[i][3], qolgan:rows[i][4] };
  }
  return { jami:0, sarflangan:0, qolgan:0 };
}

const HDR_MGR_PAY = [
  'Отметка времени','Sana','Menejer ID','Menejer F.I.Sh','To\'lov turi',
  'Vrach F.I.Sh','Spec','Object','Район','Tel',
  'MP ID','MP Ismi',
  'Summa','Komentariya',
  'Mgr Start','Mgr End','Mgr Lat','Mgr Lng',
  'MP Lat','MP Lng',
  'Masofa (m)','Shubhali (FAKE)','Holat',
  'REF',
];

function mgrPayDoctor(d) {
  const sh = getOrCreate(OUT, OUT_TABS.MGR_PAYMENTS, HDR_MGR_PAY, '#7a3ca0');
  const summa = Number(d.summa) || 0;

  const bal = getMgrBalance(d.mgrId);
  if (summa > bal.qolgan) {
    return { error: 'Balansda yetarli mablag\' yo\'q! Qolgan: ' + bal.qolgan.toLocaleString() + ' so\'m' };
  }

  let masofa = '', shubhali = 'Yo\'q', holat = 'Yo\'q';
  if (d.type === 'PROMO') {
    if (d.mgrLat && d.mpLat) {
      masofa = Math.round(haversine(d.mgrLat, d.mgrLng, d.mpLat, d.mpLng));
      if (masofa > 200) { shubhali = 'HA'; holat = 'Dvoynoy vizit EMAS'; }
      else { holat = 'Dvoynoy vizit'; }
    } else {
      shubhali = 'HA (lokatsiya yo\'q)'; holat = 'Dvoynoy vizit EMAS';
    }
  }

  const ref = 'PAY-' + Date.now();
  const row = [
    new Date().toISOString(), d.date, d.mgrId, d.mgrName, d.type,
    d.doctorName, d.doctorSpec, d.doctorObject, d.doctorDistrict, d.doctorPhone,
    d.type==='PROMO' ? d.mpId : '', d.type==='PROMO' ? d.mpName : '',
    summa, d.comment,
    d.mgrStart, d.mgrEnd, d.mgrLat||'', d.mgrLng||'',
    d.type==='PROMO' ? (d.mpLat||'') : '', d.type==='PROMO' ? (d.mpLng||'') : '',
    masofa, shubhali, holat, ref,
  ];
  sh.appendRow(row);
  const lr = sh.getLastRow();
  sh.getRange(lr,1,1,row.length).setBackground(shubhali.indexOf('HA')===0 ? '#ffd6d6' : '#d4f5e8');

  updateMgrBalanceSpent(d.mgrId, summa);
  logKPI(d.mgrId, d.mgrName, d.date, 'mgr_payment', d.type, shubhali.indexOf('HA')===0);
  return { status:'ok', ref, masofa, shubhali, holat };
}

function updateMgrBalanceSpent(mgrId, amount) {
  const sh = SpreadsheetApp.openById(OUT).getSheetByName(OUT_TABS.MGR_BALANCE);
  if (!sh) return;
  const rows = sh.getDataRange().getValues();
  for (let i=1;i<rows.length;i++) {
    if (rows[i][0]===mgrId) {
      const newSpent = Number(rows[i][3]||0) + amount;
      const newRemain = Number(rows[i][2]||0) - newSpent;
      sh.getRange(i+1,4).setValue(newSpent);
      sh.getRange(i+1,5).setValue(newRemain);
      sh.getRange(i+1,6).setValue(new Date().toISOString());
      return;
    }
  }
}

function getMgrPayments(mgrId, date) {
  const sh = SpreadsheetApp.openById(OUT).getSheetByName(OUT_TABS.MGR_PAYMENTS);
  if (!sh) return [];
  const rows = sh.getDataRange().getValues();
  const hdr = rows[0]; const out=[];
  for (let i=1;i<rows.length;i++) {
    const r=rows[i]; if(!r[1]) continue;
    if (mgrId && r[2]!==mgrId) continue;
    if (date && r[1]!==date) continue;
    const item={}; hdr.forEach((h,j)=>item[h]=r[j]);
    out.push(item);
  }
  return out;
}

// ════════════════════════════════════════════════════════════════
// YANGI VRACH / APTEKA
// ════════════════════════════════════════════════════════════════
const HDR_ND = ['РЕГИОН','Ф.И.О Врача','Объект','Специальность','Район','Телефон','Категория','Состояние','Hodim','Vaqt'];
function addNewDoctor(d) {
  const sh = getOrCreate(OUT, OUT_TABS.NEW_DOCTORS, HDR_ND, '#0f6e56');
  sh.appendRow([d.region,d.name,d.object,d.specialty,d.district,d.phone,d.category||'',d.status||'Active',d.empName,new Date().toISOString()]);
  return { status:'ok' };
}
const HDR_NP = ['РЕГИОН','РАЙОН','ИНН','Apteka nomi','Filial','Hodim','Vaqt'];
function addNewPharmacy(d) {
  const inn = String(d.inn||'').replace(/\s/g,'');
  if (inn.length!==9 || isNaN(inn)) return { error:'INN 9 raqam bo\'lishi shart' };
  const sh = getOrCreate(OUT, OUT_TABS.NEW_PHARM, HDR_NP, '#0f6e56');
  sh.appendRow([d.region,d.district,inn,d.name,d.branchNo||'',d.empName,new Date().toISOString()]);
  return { status:'ok' };
}

// ════════════════════════════════════════════════════════════════
// MUROJAATLAR
// ════════════════════════════════════════════════════════════════
function submitFeedback(d) {
  const sh = getOrCreate(OUT, OUT_TABS.FEEDBACK, ['Yuborilgan sana','Hodim ID','Hodim F.I.Sh','Xabar matni','Murojaat turi'], '#4a35a0');
  sh.appendRow([new Date().toISOString(), d.empId, d.empName, d.message, d.type||'Umumiy']);
  try { MailApp.sendEmail(ADMIN_EMAIL,'[FF] Murojaat: '+d.empName, d.message); } catch(e){}
  return { status:'ok' };
}

// ════════════════════════════════════════════════════════════════
// KPI
// ════════════════════════════════════════════════════════════════
function logKPI(empId, empName, date, type, result, fake) {
  const sh = getOrCreate(OUT, OUT_TABS.KPI_LOG, ['Sana','empId','empName','Tur','Natija','Fake','Vaqt'], '#0e2248');
  sh.appendRow([date, empId, empName, type, result||'', fake?'HA':'Yo\'q', Utilities.formatDate(new Date(),'Asia/Tashkent','HH:mm:ss')]);
}

function getKPI(empId, role, dateFilter) {
  const sh = SpreadsheetApp.openById(OUT).getSheetByName(OUT_TABS.KPI_LOG);
  if (!sh) return {};
  const rows = sh.getDataRange().getValues();
  const target = dateFilter || Utilities.formatDate(new Date(),'Asia/Tashkent','yyyy-MM-dd');
  const summary = {};
  for (let i=1;i<rows.length;i++) {
    const date=rows[i][0],eId=rows[i][1],eName=rows[i][2],type=rows[i][3],result=rows[i][4];
    if (String(date)!==target) continue;
    if (role!=='admin' && role!=='manager' && eId!==empId) continue;
    if (!summary[eId]) summary[eId]={empName:eName,doctorV:0,pharmV:0,total:0,positive:0};
    if (type==='mp_doctor') { summary[eId].doctorV++; summary[eId].total++; }
    if (type==='ta_pharmacy') { summary[eId].pharmV++; summary[eId].total++; }
    if (result==='ISHLAYDI') summary[eId].positive++;
  }
  Object.keys(summary).forEach(id => {
    const s = summary[id];
    const pctDoc = KPI_NORM.doctorVisits>0 ? Math.round(s.doctorV/KPI_NORM.doctorVisits*100) : 0;
    const pctPharm = TP_NORM_PHARMACY>0 ? Math.round(s.pharmV/TP_NORM_PHARMACY*100) : 0;
    s.pct = s.doctorV>0 ? pctDoc : (s.pharmV>0 ? pctPharm : 0);
  });
  return summary;
}

function endDay(d) {
  logKPI(d.empId, d.empName, d.date, 'END_DAY', 'Yakunlandi', false);
  try {
    const kpi = getKPI(d.empId, d.role, d.date)[d.empId] || {};
    MailApp.sendEmail(ADMIN_EMAIL, '[FF] Kun yakunlandi: '+d.empName,
      'Sana: '+d.date+'\nVrach: '+(kpi.doctorV||0)+'\nApteka: '+(kpi.pharmV||0)+'\nKPI: '+(kpi.pct||0)+'%');
  } catch(e) {}
  return { status:'ok' };
}

// ════════════════════════════════════════════════════════════════
// LOKATSIYALAR (XARITA UCHUN)
// ════════════════════════════════════════════════════════════════
function logLocation(empId, empName, role, type, targetName, lat, lng, date) {
  const sh = getOrCreate(OUT, OUT_TABS.LOCATIONS, ['Sana','empId','empName','role','Tur','Ob\'ekt','Lat','Lng'], '#4a35a0');
  sh.appendRow([date, empId, empName, role, type, targetName, lat, lng]);
}

function getLocations(empId, role, days) {
  const sh = SpreadsheetApp.openById(OUT).getSheetByName(OUT_TABS.LOCATIONS);
  if (!sh) return [];
  const rows = sh.getDataRange().getValues();
  const cutoff = new Date(); cutoff.setDate(cutoff.getDate() - (Number(days)||30));
  const cutoffStr = Utilities.formatDate(cutoff, 'Asia/Tashkent', 'yyyy-MM-dd');
  const out = [];
  for (let i=1;i<rows.length;i++) {
    const r = rows[i];
    if (!r[0] || String(r[0]) < cutoffStr) continue;
    if (role !== 'admin' && role !== 'manager' && r[1] !== empId) continue;
    out.push({ date:r[0], empId:r[1], empName:r[2], role:r[3], type:r[4], target:r[5], lat:r[6], lng:r[7] });
  }
  return out;
}

// ════════════════════════════════════════════════════════════════
// YORDAMCHI FUNKSIYALAR
// ════════════════════════════════════════════════════════════════
function getOrCreate(ssId, tabName, headers, color) {
  const ss = SpreadsheetApp.openById(ssId);
  let sh = ss.getSheetByName(tabName);
  if (!sh) { sh = ss.insertSheet(tabName); sh.appendRow(headers); styleHdr(sh, headers.length, color); }
  return sh;
}
function styleHdr(sh, n, bg) {
  sh.getRange(1,1,1,n).setBackground(bg||'#0e2248').setFontColor('#fff').setFontWeight('bold').setFontSize(10);
  sh.setFrozenRows(1);
  try { sh.autoResizeColumns(1, Math.min(n,40)); } catch(e){}
}
function haversine(lat1,lon1,lat2,lon2) {
  const R=6371000, dLat=(lat2-lat1)*Math.PI/180, dLon=(lon2-lon1)*Math.PI/180;
  const a=Math.sin(dLat/2)*Math.sin(dLat/2)+Math.cos(lat1*Math.PI/180)*Math.cos(lat2*Math.PI/180)*Math.sin(dLon/2)*Math.sin(dLon/2);
  return R*2*Math.atan2(Math.sqrt(a),Math.sqrt(1-a));
}
function saveFoto(b64, ref, tag) {
  const root='FF_Fotos', month=Utilities.formatDate(new Date(),'Asia/Tashkent','yyyy-MM');
  let r = DriveApp.getFoldersByName(root).hasNext()?DriveApp.getFoldersByName(root).next():DriveApp.createFolder(root);
  let f = r.getFoldersByName(month).hasNext()?r.getFoldersByName(month).next():r.createFolder(month);
  const blob = Utilities.newBlob(Utilities.base64Decode(b64.split(',')[1]), 'image/jpeg', tag+'_'+ref+'.jpg');
  const file = f.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
  return file.getUrl();
}

// ════════════════════════════════════════════════════════════════
// OYLIK HISOBOT (Trigger orqali avtomatik ishlaydi — quyida sozlash bor)
// ════════════════════════════════════════════════════════════════
function generateMonthlyReport() {
  const kpiSh = SpreadsheetApp.openById(OUT).getSheetByName(OUT_TABS.KPI_LOG);
  if (!kpiSh) return;
  const rows = kpiSh.getDataRange().getValues();
  const now = new Date(); now.setMonth(now.getMonth()-1);
  const pm = Utilities.formatDate(now,'Asia/Tashkent','yyyy-MM');
  const ss = SpreadsheetApp.openById(OUT);
  let rSh = ss.getSheetByName('Hisobot_'+pm);
  if (!rSh) rSh = ss.insertSheet('Hisobot_'+pm); else rSh.clearContents();
  rSh.appendRow(['Hodim','Vrach','Apteka','Jami','Ijobiy','%']);
  styleHdr(rSh,6,'#0e2248');
  const sum = {};
  for (let i=1;i<rows.length;i++) {
    const date=rows[i][0],eId=rows[i][1],eName=rows[i][2],type=rows[i][3],result=rows[i][4];
    if (String(date).indexOf(pm)!==0) continue;
    if (!sum[eId]) sum[eId]={name:eName,doc:0,ph:0,total:0,pos:0};
    if (type==='mp_doctor') { sum[eId].doc++; sum[eId].total++; }
    if (type==='ta_pharmacy') { sum[eId].ph++; sum[eId].total++; }
    if (result==='ISHLAYDI') sum[eId].pos++;
  }
  Object.values(sum).forEach(s => {
    const pct = s.total>0?Math.round(s.pos/s.total*100):0;
    rSh.appendRow([s.name,s.doc,s.ph,s.total,s.pos,pct+'%']);
  });
  try { MailApp.sendEmail(ADMIN_EMAIL, '[FF] '+pm+' oylik hisobot', 'Hisobot_'+pm+' sahifasini ko\'ring'); } catch(e){}
}
